"""Verify the selected production path before opening any held-out questions."""
import hashlib
import json
import sys
from pathlib import Path
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(HERE.parent / "linked35"))
from variants import ROOT, generation, index, linked, threshold
from experiment import last_decision, usage
from policy import GEMMA, MODEL, fingerprint, full_corpus, load_dataset, rows
from run import encode, evaluate, save
from report import stats

CONFIG = HERE / "config.json"
POOL = HERE / "search.json"
QFILE = "holdout15/questions.jsonl"
GFILE = "holdout15/answer_key.jsonl"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(bank):
    pin = json.loads(CONFIG.read_text())
    if sha(bank) != pin["bank_sha256"]:
        raise ValueError("The private archive differs from the frozen bank")
    for rel, digest in pin["files"].items():
        if sha(REPO / rel) != digest:
            raise ValueError(f"Frozen code or corpus changed: {rel}")
    if (pin["model"], pin["judge"]) != (GEMMA, MODEL):
        raise ValueError("Frozen model IDs changed")
    return pin


def partition(bank, name):
    with ZipFile(bank) as archive:
        if archive.namelist().count(name) != 1:
            raise ValueError(f"Expected one member: {name}")
        records = [json.loads(line) for line in archive.read(name).splitlines() if line.strip()]
    result = {r["id"]: r for r in records}
    if len(records) != 15 or len(result) != len(records):
        raise ValueError("Expected 15 distinct question IDs")
    return result


def questions(bank):
    records = partition(bank, QFILE)
    if any(set(r) != {"id", "question"} or not r["question"].strip() for r in records.values()):
        raise ValueError("Question inputs must contain only ID and text")
    work = rows(HERE.parent / "rerank/questions35.jsonl")
    if set(records) & {r["id"] for r in work} or {r["question"] for r in records.values()} & {r["question"] for r in work}:
        raise ValueError("Holdout overlaps the working set")
    return records
