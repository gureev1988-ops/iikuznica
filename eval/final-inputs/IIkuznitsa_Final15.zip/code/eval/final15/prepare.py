"""Blind local retrieval, with the identical BM25 and pinned MiniLM used on the working set."""
import argparse
import json
import subprocess
import tempfile
from pathlib import Path

from frozen import CONFIG, HERE, POOL, REPO, encode, fingerprint, questions, rows, save, sha, verify


def prepare(bank, model_dir, python):
    verify(bank)
    qs = questions(bank)
    with tempfile.TemporaryDirectory() as temp:
        d = Path(temp)
        queries, raw, timings, ranks = (d / f for f in ("questions", "pool", "timings", "ranks"))
        queries.write_text("".join(encode(r) + "\n" for r in qs.values()))
        subprocess.run(["node", str(REPO/"eval/retrieval/search.mjs"), "--questions", str(queries), "--limit", "30",
                        "--output", str(raw), "--timings", str(timings)], check=True)
        subprocess.run([python, str(REPO/"eval/rerank/rerank.py"), "--pool", str(raw), "--model-dir",
                        str(model_dir), "--out", str(ranks)], check=True)
        search = {r["id"]: r for r in rows(raw)}
        time_by_id = {r["id"]: r["lookup_ms"] for r in rows(timings)}
        ranked = {r["id"]: r for r in rows(ranks)}
        if not qs.keys() == search.keys() == time_by_id.keys() == ranked.keys():
            raise ValueError("Incomplete retrieval")
        packed = {}
        for cid, q in qs.items():
            result = ranked[cid]
            pool = result["pool"]
            if q["question"] != search[cid]["question"] or [(p["doc"], p["ref"]) for p in search[cid]["sources"]] != [(p["doc"], p["ref"]) for p in pool]:
                raise ValueError("Candidate order changed")
            packed[fingerprint(q["question"])] = {"seeds": result["methods"]["hybrid_condition"], "pool": pool,
                                                   "search_ms": time_by_id[cid], "rerank_ms": result["rerank_ms"]}
        artifact = {"config": sha(CONFIG), "inputs": packed}
        if POOL.exists():
            # Repeatability concerns scores and selections; CPU timings vary.
            old = json.loads(POOL.read_text())
            def selection(items):
                return {k: (v["seeds"], v["pool"]) for k, v in items.items()}
            if old["config"] != artifact["config"] or selection(old["inputs"]) != selection(packed):
                raise ValueError("Reproduction differs from the frozen candidate pool")
        else:
            save(POOL, encode(artifact) + "\n")
        print(f"Prepared {len(packed)} blind retrieval results; no reference answers opened.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--bank", type=Path, required=True)
    p.add_argument("--model-dir", type=Path, required=True)
    p.add_argument("--python", required=True, help="interpreter with the frozen ONNX dependencies")
    args = p.parse_args()
    prepare(args.bank, args.model_dir, args.python)
