"""One blind, resumable run of links_threshold. Open the private reference only after all replies are saved."""
import argparse
import fcntl
import json
import os
import sys
from collections import Counter
from pathlib import Path
from urllib import error

from frozen import (CONFIG, GFILE, HERE, POOL, REPO, ROOT, encode, evaluate, fingerprint, full_corpus, generation,
                    index, last_decision, linked, load_dataset, partition, questions, save, sha, stats, threshold,
                    usage, verify)

FIELDS = ("conditions_complete", "instructions_supported", "citations_support_answer", "clarification_specific")


def load_inputs(bank):
    verify(bank)
    if sha(POOL) != (HERE / "search.sha256").read_text().strip():
        raise ValueError("Frozen retrieval cache changed")
    pack = json.loads(POOL.read_text())
    q = questions(bank)
    if pack["config"] != sha(CONFIG) or {fingerprint(r["question"]) for r in q.values()} != pack["inputs"].keys():
        raise ValueError("Search results do not match the configuration or the 15 questions")
    return q, pack["inputs"]


def collect(q, searches, out, corpus):
    norms = index()
    system = load_dataset(REPO / "eval/iikuznitsa_run12/IIkuznitsa_Run_12x3.py")["system"]
    results = {}
    for cid, item in q.items():
        lookup = searches[fingerprint(item["question"])]
        seeds = [corpus[tuple(k)] for k in lookup["seeds"]]
        case = dict(item, sources=linked(seeds, corpus, norms))
        gen = generation(out, cid, "linked_draft", case, system)
        path = evaluate(case, gen["response"], lookup["pool"], corpus, out)
        final = threshold(path["final"], last_decision(out, path))
        record = dict(id=cid, question=item["question"], final=final, served_refs=[list(k) for k in path["source_refs"]],
                      initial_refs=[[s["doc"], s["ref"]] for s in case["sources"]], decisions=path["decisions"],
                      routes_before_threshold=path["final"]["action"], cost_time=usage([gen] + path["calls"]),
                      retrieval_ms=round(lookup["search_ms"] + lookup["rerank_ms"], 3))
        done = out / "answers" / f"{cid}.json"
        if done.exists() and json.loads(done.read_text()) != record:
            raise ValueError(f"Inconsistent completion for {cid}")
        if not done.exists():
            save(done, encode(record) + "\n")
        results[cid] = record
        print(f"{len(results)}/15 answers saved", flush=True)
    return results


def score(bank, results, corpus, out):
    if len(results) != 15 or any(json.loads((out/"answers"/f"{cid}.json").read_text()) != r
                                  for cid, r in results.items()):
        raise ValueError("Expected 15 persisted final responses before opening the reference key")
    gold = partition(bank, GFILE)
    if set(results) != set(gold) or any(results[k]["question"] != g["question"] for k, g in gold.items()):
        raise ValueError("Private reference differs from saved questions")
    reviews, actions, correct, valid, direct, full_coverage = [], Counter(), Counter(), 0, 0, 0
    for cid, r in results.items():
        g, answer = gold[cid], r["final"]
        actions[g["expected_action"]] += 1
        correct[g["expected_action"]] += answer["action"] == g["expected_action"]
        cited = [(p["doc"], p["ref"]) for p in answer["sources"]]
        served = set(map(tuple, r["served_refs"]))
        reachable = all(k in served for k in cited)
        valid += answer["action"] == "answer" and bool(cited) and reachable
        direct += answer["action"] == "answer"
        anchors = {(p["doc"], p["ref"]) for p in g["evidence"]}
        full_coverage += bool(anchors) and anchors.issubset(set(map(tuple, r["initial_refs"])))
        keys = sorted(anchors | set(cited))
        reviews.append(dict(id=cid, question=r["question"], answer=answer, expected_action=g["expected_action"],
                            reference_answer=g["reference_answer"], reference_evidence=g["evidence"],
                            missing_information=g.get("missing"), originals=[corpus[k] for k in keys],
                            served_refs=r["served_refs"]))
    measured = [r["cost_time"] for r in results.values()]
    costs = [m["usd"] for m in measured]
    summary = {"configuration":"links_threshold", "n":15, "correct_action":sum(correct.values()),
               "by_action":{k: {"correct":correct[k],"n":v} for k,v in actions.items()},
               "direct_answers_with_resolvable_citations":valid, "direct_answers":direct,
               "full_initial_source_coverage": full_coverage,
               "questions_with_reference_evidence":sum(bool(g["evidence"]) for g in gold.values()),
               "api_seconds":stats([m["api_s"] for m in measured]),
               "lookup_and_rerank_seconds":stats([r["retrieval_ms"]/1000 for r in results.values()]),
               "api_usd":None if None in costs else round(sum(costs),12),
               "successful_model_calls":sum(len(m["calls"]) for m in measured)}
    save(out/"review.jsonl", "".join(encode(r) + "\n" for r in reviews))
    return summary


def manual_summary(path, results, gold_review):
    grades = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    if len(grades) != 15 or {r["id"] for r in grades} != set(results):
        raise ValueError("Expected exactly one semantic review for each of the 15 answers")
    counts = {field:Counter() for field in FIELDS}
    accepted = 0
    for r in grades:
        cid = r["id"]
        action = results[cid]["final"]["action"]
        expected = gold_review[cid]["expected_action"]
        if not isinstance(r.get("reason"), str) or not r["reason"].strip():
            raise ValueError(f"{cid}: missing explanation with source grounding")
        for field in FIELDS:
            # A wrong escalation on an answerable question still misses the mandatory content.
            required = (field == "instructions_supported" or
                        field == "conditions_complete" and "answer" in (action, expected) or
                        field == "citations_support_answer" and action == "answer" or
                        field == "clarification_specific" and "clarify" in (action, expected))
            values = ("pass", "fail") if required else ("pass", "fail", "na")
            if r.get(field) not in values:
                raise ValueError(f"{cid}: invalid or missing {field}")
            counts[field][r[field]] += 1
        accepted += action == expected and all(r[f] != "fail" for f in FIELDS)
    return {"reviewed":len(grades), "acceptable_answers":accepted, "criteria":counts}


def run(args):
    q, searches = load_inputs(args.bank)
    if args.check:
        print("Verified frozen inputs for 15 questions; no API calls and no answer key opened.")
        return
    out = args.out
    out.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (out/".holdout.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        stamp = {"config":sha(CONFIG), "search":sha(POOL), "bank":sha(args.bank)}
        pin = out/"freeze.json"
        if pin.exists() and json.loads(pin.read_text()) != stamp:
            raise ValueError("Output directory belongs to another configuration")
        save(pin, encode(stamp) + "\n")
        for folder in ("calls", "answers"):
            (out/folder).mkdir(exist_ok=True)
        if not os.environ.get("OPENROUTER_API_KEY") and not all((out/"answers"/f"{cid}.json").is_file() for cid in q):
            raise ValueError("Live generation requires OPENROUTER_API_KEY in this environment")
        corpus = full_corpus()
        results = collect(q, searches, out, corpus)
        summary = score(args.bank, results, corpus, out)
        if args.grades:
            reviews = {r["id"]:r for r in map(json.loads,(out/"review.jsonl").read_text().splitlines())}
            summary["semantic_review"] = manual_summary(args.grades, results, reviews)
        save(out/"summary.json", json.dumps(summary,ensure_ascii=False,indent=2) + "\n")
        print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--bank", type=Path, required=True)
    p.add_argument("--out", type=Path, default=HERE/"private")
    p.add_argument("--check", action="store_true")
    p.add_argument("--grades", type=Path, help="Private manual grades JSONL; replay uses the same saved responses.")
    try:
        run(p.parse_args())
    except error.HTTPError as exc:
        sys.exit(f"OpenRouter HTTP {exc.code}; resume in the same directory. Retry-After: {exc.headers.get('Retry-After','unspecified')}")
    except (OSError, KeyError, TypeError, ValueError, RuntimeError) as exc:
        sys.exit(str(exc))
