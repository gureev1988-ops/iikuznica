"""Run the frozen final 15 questions from this private, self-contained archive."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--check", action="store_true", help="validate the blind inputs, no model calls")
p.add_argument("--out", type=Path, default=Path("final15-private"), help="private, persistent results and resumable calls")
p.add_argument("--grades", type=Path, help="private JSONL assessments of all 15 saved answers")
args = p.parse_args()
out = args.out.resolve()
if not args.check:
    out.mkdir(parents=True, exist_ok=True, mode=0o700)
    ignore = out / ".gitignore"
    if not ignore.exists():
        ignore.write_text("*\n")
with TemporaryDirectory(prefix="iikuz-final15-") as work, ZipFile(sys.argv[0]) as archive:
    base = Path(work)
    for entry in archive.infolist():
        path = Path(entry.filename)
        if path.is_absolute() or ".." in path.parts:
            sys.exit("Invalid private package path")
        if path.parts[0] in ("code", "bank"):
            dest = base / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(archive.read(entry))
    cmd = [sys.executable, str(base/"code/eval/final15/holdout.py"), "--bank", str(base/"bank/bank.zip"),
           "--out", str(out)]
    if args.check:
        cmd.append("--check")
    if args.grades:
        cmd.extend(["--grades", str(args.grades.resolve())])
    sys.exit(subprocess.run(cmd, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")).returncode)
